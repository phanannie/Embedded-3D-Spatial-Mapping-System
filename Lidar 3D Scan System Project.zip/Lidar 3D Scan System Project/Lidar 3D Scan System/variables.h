extern int state;
