void PortH_Init(void);

void rotate(int steps, int delay, int dir);

void DutyCycleForward(int delay);

void DutyCycleReverse(int delay);

