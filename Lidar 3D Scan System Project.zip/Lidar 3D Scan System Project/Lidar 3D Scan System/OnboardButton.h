void EnableInt(void);
void DisableInt(void);
void WaitForInt(void);
void ExternalButton_Init(void);
void GPIOJ_IRQHandler(void);
